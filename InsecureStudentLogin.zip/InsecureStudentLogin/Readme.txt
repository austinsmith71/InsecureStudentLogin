Username: Austin, Colt or Victor
Class: APCSP
Password: 123
